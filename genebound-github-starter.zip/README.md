# Genebound GitHub Starter

A small browser-based horse genetics game starter built with plain HTML, CSS, and JavaScript.

## What's included
- Pick a mare and stallion
- Breed a foal
- Simple phenotype calculator
- Save foals to a local herd with browser storage
- Clean starter layout for expanding into a bigger game

## Files
- `index.html` - main game page
- `style.css` - styling
- `script.js` - breeding logic and herd saving

## How to use on GitHub
1. Create a new repository on GitHub.
2. Upload all four files to the repository root.
3. Go to **Settings -> Pages**.
4. Under **Build and deployment**, set the source to **Deploy from a branch**.
5. Choose the `main` branch and the `/root` folder.
6. Save, then wait for GitHub Pages to publish your site.

Your site URL will look like:
`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY-NAME/`

## Good next upgrades
- Add more genes like champagne, pearl, silver, roan, tobiano, splash, sabino, and appaloosa
- Add horse images or sprite layers
- Add money, markets, and breeding cooldowns
- Add registry IDs and pedigrees
- Add exploration for rare traits
- Add save/export features

## Notes
This starter uses a random allele pick for each parent, so it behaves like a simple playable breeding sim.
